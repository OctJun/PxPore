# PxPore sensitivity analysis raw results

This archive contains sanitized numerical outputs from the PxPore sensitivity study.

- Planned runs: 637
- Recorded runs: 589
- Missing runs: 48
- Status counts: CACHED=275, PASS=314

Included per-run files: result_stats.json, result_center.txt, result_psd.txt, and result_voxel_mc_psd.txt when produced.

Excluded as nonessential or environment-specific: staged input structures, command lines, run records, stdout/stderr, Python paths, working directories, timestamps, and host information.

The missing runs are listed in missing_runs.csv. They are not silently treated as successful.
