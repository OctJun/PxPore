# PP/PB/Zeo++ 10 nm fill benchmark

Fill percentage means occupied sites on a 0.20 nm simple-cubic candidate lattice. The nominal 0% case contains one sentinel C atom for PoreBlazer compatibility. Samples are nested and deterministic. GRO coordinates are in nm; XYZ and PB cell lengths are in angstrom.

PxPore example: `python -m PxPore fill_050/fill_050.gro ...`

PoreBlazer example: `cd fill_050 && /usr/bin/poreblazer.exe < input.dat`
