# Scaling time statistics

Values are mean ± sample standard deviation in seconds. Statistics are calculated from the raw repeated-run records.

## Wall time

| Threads | Legacy + Centers | Legacy + MC | Periodic + Centers | Periodic + MC |
|---:|---:|---:|---:|---:|
| 1 | 38.14 ± 0.02 | 43.53 ± 0.15 | 46.65 ± 6.17 | 48.34 ± 0.05 |
| 2 | 22.05 ± 0.14 | 24.56 ± 0.06 | 24.62 ± 0.06 | 27.17 ± 0.01 |
| 4 | 13.67 ± 0.05 | 14.80 ± 0.04 | 15.08 ± 0.10 | 16.25 ± 0.04 |
| 8 | 9.37 ± 0.04 | 9.83 ± 0.12 | 10.24 ± 0.03 | 10.68 ± 0.08 |
| 16 | 7.79 ± 0.01 | 7.94 ± 0.03 | 8.42 ± 0.01 | 8.60 ± 0.02 |
| 32 | 6.66 ± 0.03 | 6.59 ± 0.02 | 7.13 ± 0.02 | 7.08 ± 0.05 |
| 64 | 6.03 ± 0.05 | 5.92 ± 0.02 | 6.54 ± 0.20 | 6.41 ± 0.17 |

## CPU time

| Threads | Legacy + Centers | Legacy + MC | Periodic + Centers | Periodic + MC |
|---:|---:|---:|---:|---:|
| 1 | 38.11 ± 0.02 | 43.50 ± 0.14 | 46.65 ± 6.18 | 48.31 ± 0.05 |
| 2 | 39.70 ± 0.25 | 44.89 ± 0.10 | 44.61 ± 0.08 | 49.94 ± 0.03 |
| 4 | 41.49 ± 0.14 | 46.73 ± 0.18 | 46.41 ± 0.16 | 51.76 ± 0.09 |
| 8 | 46.09 ± 0.36 | 51.47 ± 0.52 | 51.40 ± 0.18 | 56.57 ± 0.46 |
| 16 | 57.15 ± 0.09 | 63.28 ± 0.26 | 63.43 ± 0.29 | 69.67 ± 0.06 |
| 32 | 70.42 ± 0.06 | 76.49 ± 0.31 | 76.71 ± 0.46 | 82.82 ± 0.52 |
| 64 | 99.67 ± 0.21 | 108.16 ± 0.65 | 108.83 ± 2.04 | 116.49 ± 1.08 |

## Overall change and minimum wall time

| Condition | Wall time: 1 to 64 threads | CPU time: 1 to 64 threads | Minimum wall time |
|---|---:|---:|---:|
| Legacy + Centers | -84.2% | +161.5% | 6.03 ± 0.05 (64 threads) |
| Legacy + MC | -86.4% | +148.7% | 5.92 ± 0.04 (61 threads) |
| Periodic + Centers | -86.0% | +133.3% | 6.45 ± 0.02 (61 threads) |
| Periodic + MC | -86.7% | +141.1% | 6.35 ± 0.05 (63 threads) |
