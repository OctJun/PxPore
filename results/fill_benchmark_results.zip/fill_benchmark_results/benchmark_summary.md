# 10 nm fill benchmark summary

All systems are nested random selections from 125,000 carbon candidate sites on a
0.20 nm lattice in a 10 × 10 × 10 nm³ box (seed 11451466). The nominally empty
case contains one sentinel carbon atom. Analyses used a 0.02 nm grid
(500³ = 125,000,000 voxels) and zero-radius probe.

FFV is reported separately as total and connected/accessible volume fraction.
Nominal lattice fill is not itself an FFV because atomic excluded-volume spheres
extend beyond their candidate lattice sites.

## Systems and FFV

| Case | Fill (%) | Atoms | Box (nm) | Grid | PP total FFV (%) | PP accessible (%) | PB total FFV (%) | PB accessible (%) | Zeo++ total FFV (%) | Zeo++ accessible (%) |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| fill_000 | 0 | 1 | 10 × 10 × 10 | 500³ | 99.998 | 99.998 | 99.998 | 99.998 | 100.000 | 100.000 |
| fill_010 | 10 | 12,500 | 10 × 10 × 10 | 500³ | 76.116 | 76.112 | — | — | 76.000 | 74.116 |
| fill_030 | 30 | 37,500 | 10 × 10 × 10 | 500³ | 40.639 | 40.611 | — | — | 39.934 | 34.180 |
| fill_050 | 50 | 62,500 | 10 × 10 × 10 | 500³ | 18.479 | 18.346 | — | — | — | — |
| fill_070 | 70 | 87,500 | 10 × 10 × 10 | 500³ | 6.107 | 0.046 | 6.476 | 0.000 | 5.866 | 0.756 |
| fill_090 | 90 | 112,500 | 10 × 10 × 10 | 500³ | 0.784 | 0.004 | 0.911 | 0.000 | 0.692 | 0.000 |
| fill_100 | 100 | 125,000 | 10 × 10 × 10 | 500³ | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 | 0.000 |

## Runtime and peak memory

Values are mean ± sample standard deviation over three attempts. Failed PB timings
are time-to-crash and must not be interpreted as completed runtimes.
PxPore received no explicit thread count and used 64 threads in these runs. PB and
Zeo++ ran six cases concurrently per repeat; values below are per-process wall time
and RSS and may include contention from the other concurrent cases.

| Case | PP status | PP wall | PP CPU | PP peak RSS | PB status | PB wall | PB CPU | PB peak RSS | Zeo++ status | Zeo++ wall | Zeo++ CPU | Zeo++ peak RSS |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| fill_000 | 3/3 succeeded | 9.18 ± 0.06 s | 98.02 ± 0.46 s | 2685.95 ± 0.65 MiB | 3/3 succeeded | 58.16 ± 0.12 s | 58.15 ± 0.12 s | 8648.19 ± 0.09 MiB | 3/3 succeeded | 0.97 ± 0.00 s | 0.97 ± 0.01 s | 8.54 ± 0.04 MiB |
| fill_010 | 3/3 succeeded | 25.72 ± 0.06 s | 12.34 ± 0.00 min | 10467.20 ± 0.84 MiB | 0/3 succeeded | 7.14 ± 0.01 h | 7.14 ± 0.01 h | 8027.40 ± 0.03 MiB | 3/3 succeeded | 1.53 ± 0.02 h | 1.53 ± 0.02 h | 425.58 ± 0.09 MiB |
| fill_030 | 3/3 succeeded | 18.85 ± 0.04 s | 3.61 ± 0.04 min | 15778.73 ± 0.96 MiB | 0/3 succeeded | 15.87 ± 0.04 h | 15.87 ± 0.04 h | 7189.57 ± 0.04 MiB | 3/3 succeeded | 1.30 ± 0.00 h | 1.30 ± 0.00 h | 879.40 ± 0.06 MiB |
| fill_050 | 3/3 succeeded | 18.28 ± 0.05 s | 3.50 ± 0.02 min | 12744.57 ± 1.02 MiB | 0/3 succeeded | 21.39 ± 0.04 h | 21.39 ± 0.04 h | 6664.87 ± 0.07 MiB | 0/3 succeeded | 12.50 ± 0.01 min | 12.50 ± 0.01 min | 389.42 ± 0.04 MiB |
| fill_070 | 3/3 succeeded | 11.98 ± 0.11 s | 2.75 ± 0.02 min | 9570.02 ± 0.39 MiB | 3/3 succeeded | 27.70 ± 0.01 h | 27.70 ± 0.01 h | 6425.65 ± 0.06 MiB | 3/3 succeeded | 25.11 ± 0.01 min | 25.11 ± 0.01 min | 1018.14 ± 0.05 MiB |
| fill_090 | 3/3 succeeded | 9.74 ± 0.05 s | 2.45 ± 0.00 min | 9626.02 ± 0.34 MiB | 3/3 succeeded | 31.47 ± 0.01 h | 31.47 ± 0.01 h | 6294.33 ± 0.08 MiB | 3/3 succeeded | 40.52 ± 0.01 min | 40.52 ± 0.01 min | 949.54 ± 0.12 MiB |
| fill_100 | 3/3 succeeded | 8.61 ± 0.59 s | 2.25 ± 0.01 min | 10314.98 ± 0.67 MiB | 3/3 succeeded | 33.94 ± 0.03 h | 33.94 ± 0.03 h | 6273.56 ± 0.04 MiB | 3/3 succeeded | 49.84 ± 0.06 min | 49.84 ± 0.06 min | 765.04 ± 0.16 MiB |

## Main observations

- PxPore and Zeo++ completed 18/18 runs; PoreBlazer completed 12/18.
- PoreBlazer failed reproducibly for fill_030 and fill_050 with SIGABRT
  (`munmap_chunk(): invalid pointer`) in its percolation cluster analysis.
- Total FFV agrees closely where PB completed. Connectivity-sensitive accessible
  FFV differs substantially for fill_070: total free volume remains about 6%,
  while each program classifies its connectivity differently.
- PxPore completed each case in seconds, Zeo++ in seconds to tens of minutes, and
  dense PoreBlazer cases in roughly 27–32 hours per completed run.
